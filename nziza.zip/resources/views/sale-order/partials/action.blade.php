<button class="btn btn-info btn-sm dropdown-toggle btn-flat" data-toggle="dropdown" aria-expanded="false">More</button>
<div class="dropdown-menu">
    <a href="" class="dropdown-item">View</a>
    <a href="{{route('sale-order.edit', $id)}}" class="dropdown-item">Edit</a>
    <div class="dropdown-divider"></div>
    <a href="" class="dropdown-item">Cancel Order</a>
</div>
